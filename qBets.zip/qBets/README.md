# Sports Bet App UI Flutter

Flutter based Sports Bet App UI

## Demo
Demo available on YouTube.

Link: https://youtu.be/8GBCiwqmyiA

## Screenshot

![images (8)](https://user-images.githubusercontent.com/54774962/99819628-b43d0d00-2b75-11eb-8229-38a43e45b8da.jpeg)

