class Questionslist {
  final String ques;

  Questionslist({this.ques});

  static List<Questionslist> questions = [
    Questionslist(
      ques: "this is Question 1"
    ),
    Questionslist(
      ques: "this is Question 2"
    ),
    Questionslist(
      ques: "this is Question 3"
    ),
    Questionslist(
      ques: "this is Question 4"
    ),
    Questionslist(
      ques: "this is Question 5"
    ),
    Questionslist(
      ques: "this is Question 6"
    ),
    Questionslist(
      ques: "this is Question 7"
    ),
    Questionslist(
      ques: "this is Question 8"
    ),
    Questionslist(
      ques: "this is Question 9"
    ),
    Questionslist(
      ques: "this is Question 10"
    ),
  ];
}
