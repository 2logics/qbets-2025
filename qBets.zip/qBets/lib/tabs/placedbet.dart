import 'package:flutter/material.dart';

class Placedbet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.orange,
        child: Center(
          child: Text("Placedbet"),
        ),
      ),
    );
  }
}