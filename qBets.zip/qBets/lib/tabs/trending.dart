import 'package:flutter/material.dart';

class trending extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.amberAccent,
        child: Center(
          child: Text("trending"),
        ),
      ),
    );
  }
}
