package com.example.sportshub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
